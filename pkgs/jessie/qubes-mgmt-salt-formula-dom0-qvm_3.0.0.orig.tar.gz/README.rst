===============
Dom0 qvm-* Formula
===============

Allows interaction to many of the Qubes qvm- tools via a state file or module

.. note::

See _modules/qvm.py for inline documentation

Available states
================

.. contents::
    :local:

``qvm.*``
------------

